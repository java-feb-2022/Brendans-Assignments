public class First {
    public static void main(String[] args) {
        System.out.println("My name is Brendan Angelo.");
        System.out.println("I am 27 years old.");
        System.out.println("My hometown is Granite Bay, CA");
    }
}
